#include<iostream>
using namespace std;

int main()
{
	int a,b;

	cout<<"Enter the number of apples: ";
	cin>>a;
	cout<<"Enter the number of bananas: ";
	cin>>b;
	cout<<"Total number of fruits are: "<<a+b<<endl;
	return 0;
}
